/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Sewwa
 */
public class AddTransaction {
     private static final String DB_URL = "jdbc:mysql://localhost:3306/bankdbs";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
public void addTransaction(int accNumber, int amount, String date, String reference) throws SQLException {
        String query = "INSERT INTO transaction (acc_number, amount, date, reference) VALUES (?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, accNumber);
            statement.setInt(2, amount);
            statement.setString(3, date);
            statement.setString(4, reference);
            
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new SQLException("Error adding Transaction: " + e.getMessage());
        }
    }
}
