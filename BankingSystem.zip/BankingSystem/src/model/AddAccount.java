/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Sewwa
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AddAccount {
   private static final String DB_URL = "jdbc:mysql://localhost:3306/bankdbs";
    private static final String DB_USER = "your_db_username";
    private static final String DB_PASSWORD = "your_db_password";

    public void addAccount(int accNumber, String nameInitial, String fullName, String idNumber, 
                           String address, int contact, String gender, String birthday, 
                           String openDate, double openAmount) throws SQLException {
        String query = "INSERT INTO account (acc_number, name_initial, full_name, id_number, address, contact, gender, birthday, open_date, open_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, accNumber);
            statement.setString(2, nameInitial);
            statement.setString(3, fullName);
            statement.setString(4, idNumber);
            statement.setString(5, address);
            statement.setInt(6, contact);
            statement.setString(7, gender);
            statement.setString(8, birthday);
            statement.setString(9, openDate);
            statement.setDouble(10, openAmount);

            statement.executeUpdate();
        } catch (SQLException e) {
            throw new SQLException("Error adding account: " + e.getMessage());
        }
    }
}
