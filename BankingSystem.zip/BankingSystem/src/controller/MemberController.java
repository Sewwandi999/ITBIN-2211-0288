/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.SQLException;
import model.AddMember;
import model.RemoveMember;

/**
 *
 * @author Sewwa
 */
public class MemberController {
    public static void addMember(String memberName, int age, String gender, String address, String profession)
                 throws SQLException {
        AddMember addMember = new AddMember();
        addMember.addMember(memberName, age, gender, address, profession);
    }

    public void removeMember(int memberID) throws SQLException {
        RemoveMember.removeMember(memberID);
    }
}
