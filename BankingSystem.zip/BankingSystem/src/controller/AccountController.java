/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

/**
 *
 * @author Sewwa
 */
import java.sql.ResultSet;
import model.AddAccount;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.RemoveAccount;



public class AccountController {
         public static void addAccount(int accNumber, String nameInitial, String fullName, String idNumber, 
                                  String address, int contact, String gender, String birthday, 
                                  String openDate, double openAmount) 
                 throws SQLException {
        AddAccount addAccount = new AddAccount();
        addAccount.addAccount(accNumber, nameInitial, fullName, idNumber, address, contact, gender, birthday, openDate, openAmount);
    }
         
         public void removeAccount(int accNumber) throws SQLException {
        RemoveAccount.removeAccount(accNumber);
    }
       
}
