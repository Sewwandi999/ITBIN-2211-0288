/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.SQLException;
import model.AddTransaction;
import model.RemoveTransaction;

/**
 *
 * @author Sewwa
 */
public class TransactionController {
    public static void addTransaction(int accNumber, int amount, String date, String reference)
                 throws SQLException {
        AddTransaction addTransaction = new AddTransaction();
        addTransaction.addTransaction(accNumber, amount, date, reference);
    }

    public void removeTransaction(int transID) throws SQLException {
        RemoveTransaction.removeTransaction(transID);
    }
}
